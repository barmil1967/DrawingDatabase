A Pen created at CodePen.io. You can find this one at https://codepen.io/jackrugile/pen/ABeIi.

 A simple, centered form with a pulsing glow effect on the input during focus.

This was an entry for a WebDesign Tuts post here: http://webdesign.tutsplus.com/articles/workshops/community-project-style-a-simple-search-form/